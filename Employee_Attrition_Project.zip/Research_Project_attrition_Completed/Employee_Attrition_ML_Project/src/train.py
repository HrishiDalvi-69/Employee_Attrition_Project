import warnings
warnings.filterwarnings("ignore")
import json
import joblib
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import (train_test_split,StratifiedKFold,cross_validate)
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import (accuracy_score,precision_score,recall_score,f1_score,roc_auc_score,confusion_matrix,classification_report,roc_curve)
from sklearn.inspection import permutation_importance
from .config import *
from .data_utils import load_data, clean_data

# PREPROCESSING
# ---------------------------------------------------------
def prep():
    cat = Pipeline([
        (
            "imputer",
            SimpleImputer(strategy="most_frequent")
        ),
        (
            "onehot",
            OneHotEncoder(
                handle_unknown="ignore",
                sparse_output=False
            )
        )
    ])
    num = Pipeline([
        (
            "imputer",
            SimpleImputer(strategy="median")
        ),
        (
            "scaler",
            StandardScaler()
        )
    ])
    return ColumnTransformer([
        (
            "cat",
            cat,
            CATEGORICAL_FEATURES
        ),
        (
            "num",
            num,
            NUMERICAL_FEATURES
        )
    ])

# MACHINE LEARNING MODELS
# ---------------------------------------------------------
def get_models():
    return {
        "Logistic Regression": LogisticRegression(
            max_iter=2000,
            class_weight="balanced",
            random_state=RANDOM_STATE
        ),
        "Decision Tree": DecisionTreeClassifier(
            max_depth=6,
            min_samples_leaf=10,
            class_weight="balanced",
            random_state=RANDOM_STATE
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=300,
            max_depth=12,
            min_samples_leaf=3,
            class_weight="balanced",
            random_state=RANDOM_STATE,
            n_jobs=-1
        ),
        "Support Vector Machine": SVC(
            kernel="rbf",
            probability=True,
            class_weight="balanced",
            random_state=RANDOM_STATE
        )
    }

# MODEL EVALUATION SCORES
# ---------------------------------------------------------
def scores(model, X, y):
    predictions = model.predict(X)
    probabilities = model.predict_proba(X)[:, 1]
    return {
        "Accuracy": accuracy_score(y, predictions),
        "Precision": precision_score(
            y,
            predictions,
            zero_division=0
        ),
        "Recall": recall_score(
            y,
            predictions,
            zero_division=0
        ),
        "F1 Score": f1_score(
            y,
            predictions,
            zero_division=0
        ),
        "ROC AUC": roc_auc_score(
            y,
            probabilities
        )
    }

# MAIN FUNCTION
# ---------------------------------------------------------
def main():
    # Create required directories
    for directory in (
        MODEL_DIR,
        REPORT_DIR,
        FIGURE_DIR
    ):
        directory.mkdir(
            parents=True,
            exist_ok=True
        )

    # LOAD AND CLEAN DATA
    # -----------------------------------------------------
    raw = load_data()
    df = clean_data(raw)
    X = df[FEATURES]
    y = df[TARGET]
   
    # DATASET SUMMARY
    # -----------------------------------------------------
    dataset_summary = (
        f"Rows: {len(df)}\n"
        f"Columns: {len(raw.columns)}\n"
        f"Missing cells: {int(raw.isna().sum().sum())}\n"
        f"Duplicates: {int(raw.duplicated().sum())}\n\n"
        f"Target:\n"
        f"{df[TARGET].value_counts().sort_index()}\n\n"
        f"Columns:\n"
        f"{raw.columns.tolist()}"
    )
    (
        REPORT_DIR / "dataset_summary.txt"
    ).write_text(
        dataset_summary,
        encoding="utf-8"
    )

    # GENERATE DATASET VISUALIZATIONS
    # -----------------------------------------------------
    visualizations = [
        (
            "attrition_distribution.png",
            "Attrition Distribution",
            "LeaveOrNot"
        ),
        (
            "attrition_by_city.png",
            "Attrition by City",
            "City"
        ),
        (
            "attrition_by_payment_tier.png",
            "Attrition by Payment Tier",
            "PaymentTier"
        ),
        (
            "attrition_by_education.png",
            "Attrition by Education",
            "Education"
        )
    ]
    for filename, title, column in visualizations:
        plt.figure(figsize=(8, 5))
        if column == "LeaveOrNot":
            counts = (
                df[column]
                .value_counts()
                .sort_index()
            )
            plt.bar(
                counts.index.astype(str),
                counts.values
            )
        else:
            table = pd.crosstab(
                df[column],
                df[TARGET]
            )
            table.plot(
                kind="bar",
                ax=plt.gca()
            )
        plt.title(title)
        plt.tight_layout()
        plt.savefig(
            FIGURE_DIR / filename,
            dpi=140
        )
        plt.close()
    # AGE VS ATTRITION
    # -----------------------------------------------------
    plt.figure(figsize=(8, 5))
    sns.boxplot(data=df,x=TARGET,y="Age")
    plt.title("Age Distribution by Attrition")
    plt.tight_layout()
    plt.savefig(FIGURE_DIR / "age_vs_attrition.png",dpi=140)
    plt.close()

    # TRAIN / TEST SPLIT
    # -----------------------------------------------------
    Xtr, Xte, ytr, yte = train_test_split(X,y,test_size=TEST_SIZE,stratify=y,random_state=RANDOM_STATE)
    fitted = []
    rows = []

    # TRAIN ALL MODELS
    # -----------------------------------------------------
    for name, estimator in get_models().items():
        model = Pipeline([
            (
                "preprocessor",
                prep()
            ),
            (
                "model",
                estimator
            )
        ])
        # Train model
        model.fit(Xtr,ytr)
        fitted.append((name, model))
        # Calculate evaluation scores
        rows.append({
            "Model": name,
            **scores(model,Xte,yte
            )
        })
       
        # CONFUSION MATRIX
        # -------------------------------------------------
        predictions = model.predict(Xte)
        plt.figure(figsize=(5, 4))
        sns.heatmap(confusion_matrix(
                yte,
                predictions
            ),
            annot=True,
            fmt="d",
            cmap="Blues",
            cbar=False
        )
        plt.title("Confusion Matrix - " + name)
        plt.tight_layout()
        filename = ("confusion_"+ name.lower().replace(" ", "_")+ ".png")
        plt.savefig(FIGURE_DIR / filename,dpi=140)
        plt.close()

    # MODEL COMPARISON
    # -----------------------------------------------------
    comp = (
        pd.DataFrame(rows)
        .sort_values(
            [
                "F1 Score",
                "Recall",
                "ROC AUC"
            ],
            ascending=False
        )
        .reset_index(drop=True)
    )
    comp.to_csv(
        REPORT_DIR / "model_comparison.csv",
        index=False
    )

    # SELECT BEST MODEL
    # -----------------------------------------------------
    best_name = comp.iloc[0].Model
    best = dict(fitted)[best_name]
    # Save trained model
    joblib.dump(
        best,
        MODEL_DIR / "best_model.joblib"
    )
    # Save model metadata
    metadata = {
        "best_model": best_name,
        "features": FEATURES,
        "target": TARGET
    }
    (
        MODEL_DIR / "model_metadata.json"
    ).write_text(
        json.dumps(
            metadata,
            indent=2
        ),
        encoding="utf-8"
    )
    # CLASSIFICATION REPORT
    # -----------------------------------------------------
    predictions = best.predict(Xte)
    probabilities = (
        best.predict_proba(Xte)[:, 1]
    )
    report = (
        "BEST MODEL: "
        + best_name
        + "\n\n"
        + classification_report(
            yte,
            predictions,
            target_names=[
                "Stay",
                "Leave"
            ],
            zero_division=0
        )
        + f"\nROC AUC: "
        f"{roc_auc_score(yte, probabilities):.4f}\n"
    )
    (
        REPORT_DIR / "classification_report.txt"
    ).write_text(
        report,
        encoding="utf-8"
    )
    # ROC CURVE COMPARISON
    # -----------------------------------------------------
    plt.figure(figsize=(8, 6))
    for name, model in fitted:
        probabilities = (model.predict_proba(Xte)[:, 1])
        fpr, tpr, _ = roc_curve(yte,probabilities)
        auc_score = roc_auc_score(yte,probabilities)
        plt.plot(fpr,tpr,label=f"{name} (AUC={auc_score:.3f})")
    plt.plot([0, 1],[0, 1],"--")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve Comparison")
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIGURE_DIR / "roc_comparison.png",dpi=140)
    plt.close()

    # FEATURE IMPORTANCE
    # -----------------------------------------------------
    permutation = permutation_importance(best,Xte,yte,n_repeats=5,random_state=RANDOM_STATE,scoring="f1",n_jobs=-1)
    importance = pd.DataFrame({
        "Feature": Xte.columns,
        "Importance_Mean": permutation.importances_mean,
        "Importance_Std": permutation.importances_std
    })
    importance = (
        importance
        .sort_values(
            "Importance_Mean",
            ascending=False
        )
    )
    importance.to_csv(REPORT_DIR / "feature_importance.csv", index=False)
    # Top 10 features
    top = (importance.head(10).sort_values("Importance_Mean"))
    plt.figure(figsize=(9, 5))
    plt.barh(top.Feature,top.Importance_Mean)
    plt.title("Top Feature Importance - "+ best_name)
    plt.tight_layout()
    plt.savefig(FIGURE_DIR / "feature_importance.png",dpi=140)
    plt.close()

    # CROSS VALIDATION
    # -----------------------------------------------------
    cv = StratifiedKFold(n_splits=5,shuffle=True,random_state=RANDOM_STATE)
    cross_validation = cross_validate(
        best,
        X,
        y,
        cv=cv,
        scoring=[
            "accuracy",
            "precision",
            "recall",
            "f1",
            "roc_auc"
        ],
        n_jobs=-1
    )
    cv_results = pd.DataFrame({
        "Metric": [
            "Accuracy",
            "Precision",
            "Recall",
            "F1",
            "ROC AUC"
        ],
        "Mean": [
            cross_validation[
                "test_accuracy"
            ].mean(),

            cross_validation[
                "test_precision"
            ].mean(),

            cross_validation[
                "test_recall"
            ].mean(),

            cross_validation[
                "test_f1"
            ].mean(),

            cross_validation[
                "test_roc_auc"
            ].mean()
        ],
        "Std": [
            cross_validation[
                "test_accuracy"
            ].std(),

            cross_validation[
                "test_precision"
            ].std(),

            cross_validation[
                "test_recall"
            ].std(),

            cross_validation[
                "test_f1"
            ].std(),

            cross_validation[
                "test_roc_auc"
            ].std()
        ]
    })
    cv_results.to_csv(REPORT_DIR / "cross_validation.csv",index=False)

    # FINAL OUTPUT
    # -----------------------------------------------------
    print(comp.to_string(index=False))
    print("BEST:",best_name)

# RUN PROGRAM
# ---------------------------------------------------------
if __name__ == "__main__":
    main()
