from pathlib import Path
ROOT_DIR=Path(__file__).resolve().parents[1]
DATA_PATH=ROOT_DIR/'data'/'Employee.csv'
MODEL_DIR=ROOT_DIR/'models'; REPORT_DIR=ROOT_DIR/'reports'; FIGURE_DIR=REPORT_DIR/'figures'
TARGET='LeaveOrNot'
FEATURES=['Education','JoiningYear','City','PaymentTier','Age','Gender','EverBenched','ExperienceInCurrentDomain']
CATEGORICAL_FEATURES=['Education','City','Gender','EverBenched']
NUMERICAL_FEATURES=['JoiningYear','PaymentTier','Age','ExperienceInCurrentDomain']
RANDOM_STATE=42; TEST_SIZE=.20
