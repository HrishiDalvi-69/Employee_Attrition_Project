import pandas as pd
import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler, LabelEncoder
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix


def prepare_dataset(df, target):
    data = df.copy()
    data = data.dropna(axis=1, how='all')
    data = data.drop_duplicates().reset_index(drop=True)
    if target not in data.columns:
        raise ValueError('Selected target column was not found.')
    data = data.dropna(subset=[target]).reset_index(drop=True)
    if data[target].nunique() != 2:
        raise ValueError('This generic attrition trainer currently supports exactly 2 target classes (binary classification).')
    X = data.drop(columns=[target])
    y_raw = data[target].astype(str)
    # Drop columns that contain only one value; they cannot help prediction.
    constant_cols = [c for c in X.columns if X[c].nunique(dropna=False) <= 1]
    X = X.drop(columns=constant_cols)
    if X.shape[1] == 0:
        raise ValueError('No usable feature columns remain after removing constant columns.')
    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(y_raw)
    return X, y, label_encoder, constant_cols


def build_preprocessor(X):
    categorical = X.select_dtypes(include=['object', 'category', 'bool']).columns.tolist()
    numerical = [c for c in X.columns if c not in categorical]
    transformers = []
    if categorical:
        transformers.append(('cat', Pipeline([
            ('imputer', SimpleImputer(strategy='most_frequent')),
            ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
        ]), categorical))
    if numerical:
        transformers.append(('num', Pipeline([
            ('imputer', SimpleImputer(strategy='median')),
            ('scaler', StandardScaler())
        ]), numerical))
    return ColumnTransformer(transformers=transformers, remainder='drop')


def get_models():
    return {
        'Logistic Regression': LogisticRegression(max_iter=2000, class_weight='balanced', random_state=42),
        'Decision Tree': DecisionTreeClassifier(max_depth=8, min_samples_leaf=5, class_weight='balanced', random_state=42),
        'Random Forest': RandomForestClassifier(n_estimators=200, max_depth=12, min_samples_leaf=3, class_weight='balanced', random_state=42, n_jobs=-1),
        'Support Vector Machine': SVC(kernel='rbf', probability=True, class_weight='balanced', random_state=42),
    }


def train_models(df, target, test_size=0.2):
    X, y, label_encoder, constant_cols = prepare_dataset(df, target)
    if len(np.unique(y)) != 2:
        raise ValueError('Target must contain two classes.')
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, stratify=y, random_state=42
    )
    results = []
    fitted = {}
    predictions = {}
    probabilities = {}
    for name, estimator in get_models().items():
        pipe = Pipeline([('preprocessor', build_preprocessor(X)), ('model', estimator)])
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        prob = pipe.predict_proba(X_test)[:, 1]
        results.append({
            'Model': name,
            'Accuracy': accuracy_score(y_test, pred),
            'Precision': precision_score(y_test, pred, zero_division=0),
            'Recall': recall_score(y_test, pred, zero_division=0),
            'F1 Score': f1_score(y_test, pred, zero_division=0),
            'ROC AUC': roc_auc_score(y_test, prob),
        })
        fitted[name] = pipe
        predictions[name] = pred
        probabilities[name] = prob
    comparison = pd.DataFrame(results).sort_values(['F1 Score', 'Recall', 'ROC AUC'], ascending=False).reset_index(drop=True)
    best_name = comparison.iloc[0]['Model']
    best = fitted[best_name]
    best_pred = best.predict(X_test)
    best_prob = best.predict_proba(X_test)[:, 1]
    cm = confusion_matrix(y_test, best_pred)
    return {
        'comparison': comparison,
        'models': fitted,
        'predictions': predictions,
        'probabilities': probabilities,
        'best_name': best_name,
        'best_model': best,
        'X': X,
        'y': y,
        'X_test': X_test,
        'y_test': y_test,
        'best_pred': best_pred,
        'best_prob': best_prob,
        'confusion_matrix': cm,
        'label_encoder': label_encoder,
        'features': X.columns.tolist(),
        'constant_columns_removed': constant_cols,
        'class_names': label_encoder.classes_.tolist(),
        'rows_used': len(X),
    }
