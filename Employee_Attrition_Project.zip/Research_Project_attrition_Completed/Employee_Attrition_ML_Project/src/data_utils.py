import pandas as pd
from .config import DATA_PATH,FEATURES,TARGET
def load_data(path=DATA_PATH):
    df=pd.read_csv(path); missing=[c for c in FEATURES+[TARGET] if c not in df.columns]
    if missing: raise ValueError('Missing required columns: '+', '.join(missing))
    return df
def clean_data(df):
    df=df.drop_duplicates().reset_index(drop=True); df=df.dropna(subset=[TARGET]).reset_index(drop=True)
    df[TARGET]=pd.to_numeric(df[TARGET],errors='raise').astype(int); return df
