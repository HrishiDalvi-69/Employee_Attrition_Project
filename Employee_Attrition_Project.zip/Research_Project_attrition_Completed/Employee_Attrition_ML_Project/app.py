from pathlib import Path
import json
import joblib
import pandas as pd
import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve
from sklearn.inspection import permutation_importance
from sklearn.metrics import classification_report
from src.config import DATA_PATH, MODEL_DIR, REPORT_DIR, FEATURES
from src.generic_trainer import train_models
st.set_page_config(page_title='Employee Attrition Prediction System',page_icon='📊',layout='wide')
MODEL_PATH = MODEL_DIR / 'best_model.joblib'
META = MODEL_DIR / 'model_metadata.json'
IMP = REPORT_DIR / 'feature_importance.csv'

@st.cache_resource
def load_saved_model():
    return joblib.load(MODEL_PATH) if MODEL_PATH.exists() else None

@st.cache_data
def load_original_data():
    return pd.read_csv(DATA_PATH)

@st.cache_data
def load_importance():
    return pd.read_csv(IMP) if IMP.exists() else pd.DataFrame()

saved_model = load_saved_model()
df = load_original_data()
imp = load_importance()
st.title('📊 Employee Attrition Prediction System')
st.caption('Machine Learning-Based Employee Attrition Prediction ' 'in Indian IT Companies'
)
mode = st.sidebar.radio('Choose Project Mode',['🟢 Trained Model', '🔵 New Dataset Training'])

# MODE 1: EXISTING TRAINED MODEL
# =========================================================

if mode.startswith('🟢'):
    if saved_model is None:
        st.error('Saved model not found. Run: python -m src.train')
        st.stop()
    meta = json.loads(META.read_text(encoding='utf-8'))
    best = meta['best_model']
    t1, t2, t3, t4, t5 = st.tabs([
        '🏠 Overview',
        '📈 Dataset Insights',
        '🤖 Model Performance',
        '🔮 Predict',
        '💡 Explainability'
    ])
    # OVERVIEW
    # -----------------------------------------------------
    with t1:
        a, b, c, d = st.columns(4)
        a.metric('Employees', f'{len(df):,}')
        b.metric('Features', len(FEATURES))
        c.metric('Attrition Cases', int(df.LeaveOrNot.sum()))
        d.metric('Best Model', best)
    # DATASET INSIGHTS
    # -----------------------------------------------------
    with t2:
        st.subheader('Dataset Insights')
        counts = df.LeaveOrNot.value_counts().sort_index()
        counts.index = counts.index.map({0: 'Stay',1: 'Leave'})
        st.bar_chart(counts)
        x, y = st.columns(2)
        x.dataframe(pd.crosstab(df.City, df.LeaveOrNot),use_container_width=True)
        y.dataframe(pd.crosstab(df.PaymentTier, df.LeaveOrNot),use_container_width=True)
        st.dataframe(df.head(20),use_container_width=True)
    # MODEL PERFORMANCE
    # -----------------------------------------------------
    with t3:
        p = REPORT_DIR / 'model_comparison.csv'
        cv = REPORT_DIR / 'cross_validation.csv'
        if p.exists():
            q = pd.read_csv(p)
            st.dataframe(q,use_container_width=True)
            st.bar_chart(q.set_index('Model')[['Accuracy', 'F1 Score', 'ROC AUC']])
        if cv.exists():
            st.subheader('5-Fold Cross-Validation')
            st.dataframe(pd.read_csv(cv),use_container_width=True)
    # PREDICTION
    # -----------------------------------------------------
    with t4:
        st.subheader('Predict Attrition for an Employee')
        l, r = st.columns(2)
        education = l.selectbox('Education',sorted(df.Education.unique()))
        joining = l.number_input(
            'Joining Year',
            int(df.JoiningYear.min()),
            int(df.JoiningYear.max()),
            int(df.JoiningYear.median())
        )
        city = l.selectbox('City',sorted(df.City.unique()))
        tier = l.selectbox('Payment Tier',sorted(df.PaymentTier.unique()))
        age = l.number_input(
            'Age',
            int(df.Age.min()),
            int(df.Age.max()),
            int(df.Age.median())
        )
        gender = r.selectbox('Gender',sorted(df.Gender.unique()))
        benched = r.selectbox('Ever Benched',sorted(df.EverBenched.unique()))
        exp = r.number_input(
            'Experience in Current Domain',
            int(df.ExperienceInCurrentDomain.min()),
            int(df.ExperienceInCurrentDomain.max()),
            int(df.ExperienceInCurrentDomain.median())
        )
        emp = {
            'Education': education,
            'JoiningYear': joining,
            'City': city,
            'PaymentTier': tier,
            'Age': age,
            'Gender': gender,
            'EverBenched': benched,
            'ExperienceInCurrentDomain': exp
        }
        if st.button(
            '🔍 Predict Attrition',
            type='primary',
            use_container_width=True
        ):
            row = pd.DataFrame([emp])[FEATURES]
            prob = float(
                saved_model.predict_proba(row)[0, 1]
            )
            pred = int(prob >= .5)
            risk = (
                'High' if prob >= .7
                else ('Medium' if prob >= .4 else 'Low')
            )
            a, b, c = st.columns(3)
            a.metric(
                'Prediction',
                'Likely to Leave' if pred else 'Likely to Stay'
            )
            b.metric(
                'Probability',
                f'{prob:.1%}'
            )
            c.metric(
                'Risk',
                risk
            )
            (
                st.error if risk == 'High'
                else st.warning if risk == 'Medium'
                else st.success
            )(f'{risk} attrition risk')
            st.subheader('Suggested Retention Actions')
            acts = []
            if prob >= .4:
                acts.append('Schedule an HR/manager check-in to understand employee concerns.')
            if tier <= 1:
                acts.append('Review compensation and career progression against the employee role.')
            if exp <= 1:
                acts.append('Consider mentoring, skill development and a clearer growth path.')
            if benched == 'Yes':
                acts.append('Review project allocation and prolonged bench periods.')
            if age <= 25:
                acts.append('Consider structured onboarding, mentorship and early-career development.' )
            if not acts:
                acts = ['Continue regular engagement and career-development discussions.']
            for act in acts:
                st.write('• ' + act)
    # EXPLAINABILITY
    # -----------------------------------------------------
    with t5:
        st.subheader('Explainability')
        st.write(
            'Permutation importance estimates which variables '
            'most affect model performance. It is not a causal '
            'explanation.'
        )
        st.dataframe(imp,use_container_width=True)
        if not imp.empty:
            st.bar_chart(imp.head(10).set_index('Feature')['Importance_Mean'])

# =========================================================
# MODE 2: NEW DATASET TRAINING
# =========================================================
else:
    st.header('🔵 New Dataset Training')
    st.write(
        'Upload a new employee/HR CSV. This mode performs a '
        'complete fresh ML workflow: dataset inspection, EDA, '
        'preprocessing, four-model comparison, confusion matrix, '
        'ROC curves, feature importance and classification report.'
    )
    uploaded = st.file_uploader('Upload a new CSV dataset',type=['csv'])
    if uploaded is None:
        st.info(
            'Recommended: upload another employee/HR attrition '
            'dataset. The columns can be different from Employee.csv, '
            'but the selected target must be a binary classification target.'
        )
        st.stop()
    try:
        new_df = pd.read_csv(uploaded)
    except Exception as e:
        st.error(f'Could not read the CSV: {e}')
        st.stop()
    # -----------------------------------------------------
    # DATASET SUMMARY
    # -----------------------------------------------------
    st.success(
        f'Dataset loaded: {len(new_df):,} rows × '
        f'{len(new_df.columns)} columns'
    )
    a, b, c, d = st.columns(4)
    a.metric('Rows', f'{len(new_df):,}')
    b.metric('Columns', len(new_df.columns))
    c.metric('Missing Cells',f'{int(new_df.isna().sum().sum()):,}')
    d.metric('Duplicate Rows',f'{int(new_df.duplicated().sum()):,}')
    # -----------------------------------------------------
    # DATASET PREVIEW
    # -----------------------------------------------------
    with st.expander(
        '📋 Preview and dataset information',
        expanded=True
    ):
        st.dataframe(
            new_df.head(15),
            use_container_width=True
        )
        info = pd.DataFrame({
            'Column': new_df.columns,

            'Data Type': [
                str(new_df[c].dtype)
                for c in new_df.columns
            ],
            'Missing': [
                int(new_df[c].isna().sum())
                for c in new_df.columns
            ],
            'Unique Values': [
                int(new_df[c].nunique(dropna=True))
                for c in new_df.columns
            ],
        })
        st.dataframe(info,use_container_width=True)
    # -----------------------------------------------------
    # SELECT TARGET COLUMN
    # -----------------------------------------------------
    target = st.selectbox('🎯 Select the target column (the column you want to predict)',new_df.columns)
    target_classes = (
        new_df[target]
        .dropna()
        .astype(str)
        .unique()
        .tolist()
    )
    st.caption(
        f'Target selected: {target} | '
        f'Classes found: {len(target_classes)}'
    )
    if len(target_classes) != 2:
        st.warning(
            'The current generic trainer supports binary '
            'classification only. Please select a target '
            'containing exactly two classes.'
        )
        st.stop()
    # -----------------------------------------------------
    # 1. EXPLORATORY DATA ANALYSIS
    # -----------------------------------------------------
    st.subheader('1. Exploratory Data Analysis')
    e1, e2 = st.columns(2)
    with e1:
        fig, ax = plt.subplots(figsize=(6, 4))
        (
            new_df[target]
            .astype(str)
            .value_counts()
            .plot(kind='bar', ax=ax)
        )
        ax.set_title('Target Distribution')
        ax.set_xlabel(target)
        ax.set_ylabel('Count')
        ax.tick_params(axis='x',rotation=20)
        st.pyplot(fig,clear_figure=True)
        plt.close(fig)
    with e2:
        numeric_cols = (new_df.select_dtypes(include=np.number).columns.tolist())
        if numeric_cols:
            selected_num = st.selectbox(
                'Numeric feature for distribution',
                numeric_cols,
                key='new_num'
            )
            fig, ax = plt.subplots(figsize=(6, 4))
            (new_df[selected_num].dropna().plot(kind='hist', bins=20, ax=ax))
            ax.set_title(f'Distribution: {selected_num}')
            ax.set_xlabel(selected_num)
            st.pyplot(fig,clear_figure=True)
            plt.close(fig)
        else:
            st.info('No numeric columns were detected for a numeric distribution plot.')
    # -----------------------------------------------------
    # CATEGORICAL DATA ANALYSIS
    # -----------------------------------------------------
    categorical_cols = (
        new_df
        .select_dtypes(
            include=['object', 'category', 'bool']
        )
        .columns
        .tolist()
    )
    if categorical_cols:
        cat = st.selectbox(
            'Categorical feature for attrition/class distribution',
            [
                c for c in categorical_cols
                if c != target
            ] or categorical_cols,
            key='new_cat'
        )
        cross = pd.crosstab(
            new_df[cat].astype(str),
            new_df[target].astype(str)
        )
        st.bar_chart(cross)
    # -----------------------------------------------------
    # TRAIN AND ANALYZE NEW DATASET
    # -----------------------------------------------------
    if st.button(
        '🚀 Train & Analyze New Dataset',
        type='primary',
        use_container_width=True
    ):
        with st.spinner(
            'Preprocessing data, training four models, '
            'and calculating evaluation results...'
        ):
            try:
                result = train_models(new_df,target)
                st.session_state['generic_result'] = result
                st.session_state['generic_target'] = target
            except Exception as e:
                st.error(f'Training could not be completed: {e}')
    result = st.session_state.get('generic_result')
    # -----------------------------------------------------
    # DISPLAY RESULTS AFTER TRAINING
    # -----------------------------------------------------
    if result:
        st.divider()

        # -------------------------------------------------
        # 2. MODEL COMPARISON
        # -------------------------------------------------
        st.subheader('2. Model Comparison')
        st.success(f"Best model: {result['best_name']}")
        comp = result['comparison'].copy()
        st.dataframe(
            comp.round(4),
            use_container_width=True
        )
        fig, ax = plt.subplots(figsize=(5, 3.5))
        x = np.arange(len(comp))
        width = 0.25
        ax.bar(x - width,comp['Accuracy'],width,label='Accuracy')
        ax.bar(x,comp['F1 Score'],width,label='F1 Score')
        ax.bar(x + width,comp['ROC AUC'],width,label='ROC AUC')
        ax.set_xticks(x)
        ax.set_xticklabels(comp['Model'],rotation=15,ha='right',fontsize=8)
        ax.set_ylim(0, 1)
        ax.set_ylabel('Score', fontsize=9)
        ax.set_title('Model Performance Comparison',fontsize=11,pad=10)
        ax.legend(fontsize=8)
        fig.tight_layout(pad=1.5)
        st.pyplot(fig,use_container_width=False)
        plt.close(fig)
        # -------------------------------------------------
        # 3. CONFUSION MATRIX
        # -------------------------------------------------
        st.subheader('3. Confusion Matrix — Best Model')
        cm = result['confusion_matrix']
        fig, ax = plt.subplots(figsize=(4, 3.5))
        im = ax.imshow(cm)
        ax.set_xticks(range(2))
        ax.set_yticks(range(2))
        ax.set_xticklabels(result['class_names'])
        ax.set_yticklabels(result['class_names'])
        ax.set_xlabel('Predicted')
        ax.set_ylabel('Actual')
        ax.set_title(f"Confusion Matrix: {result['best_name']}",fontsize=11,pad=10)
        for i in range(2):
            for j in range(2):
                ax.text(
                    j,
                    i,
                    cm[i, j],
                    ha='center',
                    va='center'
                )
        fig.colorbar(im,ax=ax,fraction=0.046,pad=0.04)
        fig.tight_layout(pad=1.5)
        st.pyplot(fig,use_container_width=False)
        plt.close(fig)
        # -------------------------------------------------
        # 4. ROC CURVE
        # -------------------------------------------------
        st.subheader('4. ROC Curve — All Models')
        fig, ax = plt.subplots(figsize=(6, 4))
        for name, prob in result['probabilities'].items():
            fpr, tpr, _ = roc_curve(
                result['y_test'],
                prob
            )
            auc = float(
                comp.loc[
                    comp['Model'] == name,
                    'ROC AUC'
                ].iloc[0]
            )
            ax.plot(fpr,tpr,label=f'{name} (AUC={auc:.3f})')
        ax.plot([0, 1],[0, 1],linestyle='--',label='Random')
        ax.set_xlabel('False Positive Rate', fontsize=9)
        ax.set_ylabel('True Positive Rate', fontsize=9)
        ax.set_title('ROC Curves',fontsize=11,pad=10)
        ax.legend(fontsize=8)
        fig.tight_layout(pad=1.5)
        st.pyplot(fig,use_container_width=False)
        plt.close(fig)
        # -------------------------------------------------
        # 5. FEATURE IMPORTANCE
        # -------------------------------------------------
        st.subheader('5. Feature Importance / Explainability')
        st.write(
            'Permutation importance estimates how much model '
            'performance changes when each original feature '
            'is shuffled. It indicates model importance, not causation.'
        )
        try:
            perm = permutation_importance(
                result['best_model'],
                result['X_test'],
                result['y_test'],
                n_repeats=5,
                random_state=42,
                scoring='f1'
            )
            fi = pd.DataFrame({
                'Feature': result['features'],
                'Importance_Mean': perm.importances_mean,
                'Importance_Std': perm.importances_std
            }).sort_values(
                'Importance_Mean',
                ascending=False
            )
            st.dataframe(fi,use_container_width=True)
            top = (fi.head(12).sort_values('Importance_Mean'))
            fig, ax = plt.subplots(figsize=(6, 4))
            ax.barh(top['Feature'],top['Importance_Mean'])
            ax.set_xlabel('Mean decrease in F1 after permutation',fontsize=9)
            ax.set_title('Feature Importance',fontsize=11,pad=10)
            ax.tick_params(axis='y',labelsize=8)
            fig.tight_layout(pad=1.5)
            st.pyplot(fig,use_container_width=False)
            plt.close(fig)
        except Exception as e:
            st.warning(f'Feature importance could not be calculated 'f'for this dataset: {e}')
        # -------------------------------------------------
        # 6. CLASSIFICATION REPORT
        # -------------------------------------------------
        st.subheader('6. Classification Report')
        st.write(
            'Class labels:',
            {
                i: name
                for i, name in enumerate(result['class_names'])
            }
        )
        report = classification_report(
            result['y_test'],
            result['best_pred'],
            target_names=result['class_names'],
            zero_division=0,
            output_dict=False
        )
        st.code(report)
        # -------------------------------------------------
        # 7. CROSS-VALIDATION
        # -------------------------------------------------
        st.subheader('7. Cross-Validation')
        st.info(
            'The main comparison above uses a stratified train/test split. '
            'For this uploaded dataset, the best model is also evaluated '
            'with 5-fold stratified cross-validation.'
        )
        from sklearn.model_selection import StratifiedKFold, cross_validate
        cv = StratifiedKFold(n_splits=5,shuffle=True,random_state=42)
        cv_rows = []
        for name, model in result['models'].items():
            scores = cross_validate(
                model,
                result['X'],
                result['y'],
                cv=cv,
                scoring=[
                    'accuracy',
                    'precision',
                    'recall',
                    'f1'
                ],
                error_score='raise'
            )
            cv_rows.append({
                'Model': name,
                'CV Accuracy': scores['test_accuracy'].mean(),
                'CV Precision': scores['test_precision'].mean(),
                'CV Recall': scores['test_recall'].mean(),
                'CV F1': scores['test_f1'].mean()
            })
        st.dataframe(pd.DataFrame(cv_rows).round(4),use_container_width=True)
        # -------------------------------------------------
        # 8. DATASET COMPATIBILITY & TRAINING SUMMARY
        # -------------------------------------------------
        st.subheader('8. Dataset Compatibility & Training Summary')
        st.write( f"Rows used after cleaning: {result['rows_used']:,}")
        st.write(f"Features used: {len(result['features'])}" )
        if result['constant_columns_removed']:
            st.write('Constant columns removed:',
                result['constant_columns_removed'])

        st.download_button(
            '⬇️ Download model comparison CSV',
            comp.to_csv(index=False).encode('utf-8'),
            'new_dataset_model_comparison.csv',
            'text/csv'
        )
        st.download_button(
            '⬇️ Download feature importance CSV',
            fi.to_csv(index=False).encode('utf-8')
            if 'fi' in locals()
            else b'Feature importance unavailable',
            'new_dataset_feature_importance.csv',
            'text/csv'
        )
