The main project is implemented as reproducible Python scripts. The notebook can be added later for presentation of EDA and model experiments.
