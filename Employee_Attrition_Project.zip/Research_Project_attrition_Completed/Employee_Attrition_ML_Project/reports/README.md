Run `python -m src.train` to regenerate all reports and figures.
